
// Placeholder for organizations router (project version).
export {};
